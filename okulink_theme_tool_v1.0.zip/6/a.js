const box = document.querySelectorAll(".color_main_01");
color_main_01.style.background = '#0000004f';


